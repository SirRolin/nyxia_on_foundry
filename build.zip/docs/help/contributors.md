# Contributors

|                                   | Original Developer                                           | Current Developer                                            |
| --------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| Name                              | Seregras (IsmaGM)                                            | Ramses800                                                    |
| Sandbox versions                  | 0 - 0.13.4                                                   | 0.14+                                                        |
| About                             | I am not a programmer. I am just a poor chemical engineer, and a big fan of ttrpgs. So yes, the code might look like Chaos (which is fine, I am a Tzeench follower myself). It might be difficult to understand why I structured things this way, and there might be a better way of organising it, I know. Just bear with me, if you tell me how and help me, we can all get a great version of Sandbox. If you need clarification, just ask me, I am @Seregras in the Foundry discord channel. | Software developer working in industry automation specialized on data acquisition & visualization |
| Like this system? Want to donate? | A) Subscribing to my Patreon here [PATREON](https://www.patreon.com/seregras?fan_landing=true) B) Promoting ttrpgs in Spanish speaking countries by subscribing to my Youtube/Twitch channels below, or sharing them on social networks. Please consider helping me even if you don't speak Spanish, because I really want my favourite hobby to be generally seen in Spain & Latinamerica as it is actually seen in English speaking countries: [Rol NL - Youtube](https://www.youtube.com/c/RolNL) [Rol NL - Twitch](https://www.twitch.tv/rolnl) C) Donating. You can do it Through: [Donate](https://streamlabs.com/rolnl/tip) | [Ko-fi](https://ko-fi.com/ramses800)                         |

## Special thanks for all the people who had helped this project so far:

- Alondaar - unwavering support and useful contributions to the code base